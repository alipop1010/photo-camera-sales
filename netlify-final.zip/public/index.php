<!DOCTYPE html>
<html>
<head>
    <title>Photo Camera Sales</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #27ae60; font-size: 24px; margin: 20px 0; }
        .info { background: #e8f4fd; padding: 15px; border-radius: 5px; margin: 15px 0; }
    </style>
</head>
<body>
    <div class="container">
        <h1>📷 Система продажи фотоаппаратов</h1>
        <div class="success">✅ Успешно развернуто на Netlify!</div>
        
        <div class="info">
            <h3>Информация о системе:</h3>
            <ul>
                <li>PHP версия: <?php echo phpversion(); ?></li>
                <li>Сервер: <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Netlify'; ?></li>
                <li>Время: <?php echo date('Y-m-d H:i:s'); ?></li>
            </ul>
        </div>

        <h2>Функционал системы:</h2>
        <ul>
            <li>🅱️ Управление брендами</li>
            <li>📸 Управление камерами</li>
            <li>👥 Управление покупателями</li>
            <li>🛒 Управление продажами</li>
        </ul>

        <p><strong>Следующий шаг:</strong> Подключение PostgreSQL базы данных</p>
    </div>
</body>
</html>
